"""Entry point for Buy-or-Wait solution (AGENTS.md §6.6).

Usage:
    python -m code.main
    python -m code.output
"""

from __future__ import annotations

import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from code.output import main

if __name__ == "__main__":
    main()
